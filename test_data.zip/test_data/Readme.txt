Test dataset variable explanations.

For the GIS_TISSA_csv the test dataset variables are the following:

dem.tif is the DEM input
soils.shp is the soils map iput
trees.shp is the trees map input
Soil_prop.csv is the table with the soil properties inputs
Veg_prop.csv is the table with the vegetation properties inputs


For the GIS_TISSA_GUI the test dataset variables are the following:

c_p1.tif and c_p2.tif are the two parameters (mean and standard deviation) for the distribution of soil cohesions
Cr_p1.tif and Cr_p2.tif are the two parameters (mean and standard deviation) for the distribution of  root cohesions
D_p1.tif and D_p2.tif are the two parameters (mean and standard deviation) for the distribution of soil depth
dem.tif is the DEM input
Hw_p1.tif and Hw_p2.tif are the two parameters (mean and standard deviation) for the distribution of soil phreatic ratios
muw_p1.tif and muw_p2.tif are the two parameters (mean and standard deviation) for the distribution of moist soil weight
phi_p1.tif and phi_p2.tif are the two parameters (mean and standard deviation) for the distribution of soil internal friction angle
qt_p1 and qt_p2 are the two parameters (mean and standard deviation) for the distribution of vegetation surcharge
suw_p1.tif and suw_p2.tif are the two parameters (mean and standard deviation) for the distribution of saturated soil weight




















